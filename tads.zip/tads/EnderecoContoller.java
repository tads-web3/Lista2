package br.edu.ifpr.foz.tads;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class EnderecoContoller {
    @GetMapping("/requisicao")
        @ResponseBody
        public String hello(HttpServletRequest request){
            String metodo = request.getMethod();
            String uri = request.getRequestURI();
            String protocolo = request.getProtocol();

            String resposta = "Metodo" + metodo + "URI" + uri + "Protocolo" + protocolo;

            return resposta;
        }
        @GetMapping("/cabecalho")
        @ResponseBody
        public String cabecalho(HttpServletRequest request){
            String host = request.getHeader("host");
            String userAGent = request.getHeader("user-agent");
            String accept = request.getHeader("accept-coding");
            String language = request.getHeader("accept-language");
            String resposta = "Host" + host + "UserAgent" + userAGent + "Accept" + accept + "Language" + language;
            return resposta;
        }
}
